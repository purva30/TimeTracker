var a = 2e3;
var b = 2e-3;
var c = 2e-5;
package timetracker

class ListProjects {
	String name
	String description
	Date dueDate
	String status
    static constraints = {
    }
}

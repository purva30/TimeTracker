package timetracker

class ListProjectsController {

    def index = {
		redirect (action:current)
	}
	
	def current = {
		def taskMgr = ListProjects.list()
		[taskMgr:taskMgr]
	}
}
